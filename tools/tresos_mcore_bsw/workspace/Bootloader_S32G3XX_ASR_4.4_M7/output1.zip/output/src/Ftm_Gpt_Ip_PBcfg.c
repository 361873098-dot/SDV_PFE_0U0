/*==================================================================================================
* Project :             RTD AUTOSAR 4.4
* Platform :            CORTEXM
* Peripheral :          Stm_Pit_Rtc_Ftm
* Dependencies :        none
*
* Autosar Version :     4.4.0
* Autosar Revision :    ASR_REL_4_4_REV_0000
* Autosar Conf.Variant :
* SW Version :          4.0.0
* Build Version :       S32_RTD_4_0_0_D2210_ASR_REL_4_4_REV_0000_20221031
*
* (c) Copyright 2022 NXP Semiconductors
* All Rights Reserved.
*
* NXP Confidential. This software is owned or controlled by NXP and may only be
* used strictly in accordance with the applicable license terms. By expressly
* accepting such terms or by downloading, installing, activating and/or otherwise
* using the software, you are agreeing that you have read, and that you agree to
* comply with and are bound by, such license terms. If you do not agree to be
* bound by the applicable license terms, then you may not retain, install,
* activate or otherwise use the software.
==================================================================================================*/
/**
 *   @file          Ftm_Gpt_Ip_PBcfg.c
 *
 *   @addtogroup    Ftm_Gpt_Ip Ftm_Gpt_Ip IPL
 *
 *   @{
 */



#ifdef __cplusplus
extern "C"{
#endif

 /*==================================================================================================
 *                                         INCLUDE FILES
 * 1) system and project includes
 * 2) needed interfaces from external units
 * 3) internal and external interfaces from this unit
 *================================================================================================*/
#include "Ftm_Gpt_Ip_PBcfg.h"
#include "Gpt_Irq.h"
/*==================================================================================================
 *                              SOURCE FILE VERSION INFORMATION
 *================================================================================================*/
#define FTM_GPT_IP_VENDOR_ID_PBCFG_C                    43
#define FTM_GPT_IP_AR_RELEASE_MAJOR_VERSION_PBCFG_C     4
#define FTM_GPT_IP_AR_RELEASE_MINOR_VERSION_PBCFG_C     4
#define FTM_GPT_IP_AR_RELEASE_REVISION_VERSION_PBCFG_C  0
#define FTM_GPT_IP_SW_MAJOR_VERSION_PBCFG_C             4
#define FTM_GPT_IP_SW_MINOR_VERSION_PBCFG_C             0
#define FTM_GPT_IP_SW_PATCH_VERSION_PBCFG_C             0
/*==================================================================================================
 *                                      FILE VERSION CHECKS
 *================================================================================================*/
#if (FTM_GPT_IP_VENDOR_ID_PBCFG_C != FTM_GPT_IP_VENDOR_ID_PBCFG_H)
    #error "Ftm_Gpt_Ip_PBcfg.c and Ftm_Gpt_Ip_PBcfg.h have different vendor ids"
#endif
/* Check if this header file and header file are of the same Autosar version */
#if ((FTM_GPT_IP_AR_RELEASE_MAJOR_VERSION_PBCFG_C != FTM_GPT_IP_AR_RELEASE_MAJOR_VERSION_PBCFG_H) || \
     (FTM_GPT_IP_AR_RELEASE_MINOR_VERSION_PBCFG_C != FTM_GPT_IP_AR_RELEASE_MINOR_VERSION_PBCFG_H) || \
     (FTM_GPT_IP_AR_RELEASE_REVISION_VERSION_PBCFG_C != FTM_GPT_IP_AR_RELEASE_REVISION_VERSION_PBCFG_H) \
    )
    #error "AutoSar Version Numbers of Ftm_Gpt_Ip_PBcfg.c and Ftm_Gpt_Ip_PBcfg.h are different"
#endif
/* Check if this header file and header file are of the same Software version */
#if ((FTM_GPT_IP_SW_MAJOR_VERSION_PBCFG_C != FTM_GPT_IP_SW_MAJOR_VERSION_PBCFG_H) || \
     (FTM_GPT_IP_SW_MINOR_VERSION_PBCFG_C != FTM_GPT_IP_SW_MINOR_VERSION_PBCFG_H) || \
     (FTM_GPT_IP_SW_PATCH_VERSION_PBCFG_C != FTM_GPT_IP_SW_PATCH_VERSION_PBCFG_H) \
    )
    #error "Software Version Numbers of Ftm_Gpt_Ip_PBcfg.c and Ftm_Gpt_Ip_PBcfg.h are different"
#endif

#if (FTM_GPT_IP_VENDOR_ID_PBCFG_C != GPT_IRQ_VENDOR_ID)
    #error "Ftm_Gpt_Ip_PBcfg.c and Gpt_Irq.h have different vendor ids"
#endif
/* Check if this header file and header file are of the same Autosar version */
#if ((FTM_GPT_IP_AR_RELEASE_MAJOR_VERSION_PBCFG_C != GPT_IRQ_AR_RELEASE_MAJOR_VERSION) || \
     (FTM_GPT_IP_AR_RELEASE_MINOR_VERSION_PBCFG_C != GPT_IRQ_AR_RELEASE_MINOR_VERSION) || \
     (FTM_GPT_IP_AR_RELEASE_REVISION_VERSION_PBCFG_C != GPT_IRQ_AR_RELEASE_REVISION_VERSION) \
    )
    #error "AutoSar Version Numbers of Ftm_Gpt_Ip_PBcfg.c and Gpt_Irq.h are different"
#endif
/* Check if this header file and header file are of the same Software version */
#if ((FTM_GPT_IP_SW_MAJOR_VERSION_PBCFG_C != GPT_IRQ_SW_MAJOR_VERSION) || \
     (FTM_GPT_IP_SW_MINOR_VERSION_PBCFG_C != GPT_IRQ_SW_MINOR_VERSION) || \
     (FTM_GPT_IP_SW_PATCH_VERSION_PBCFG_C != GPT_IRQ_SW_PATCH_VERSION) \
    )
    #error "Software Version Numbers of Ftm_Gpt_Ip_PBcfg.c and Gpt_Irq.h are different"
#endif
/*================================================================================================*/

/*==================================================================================================
 *                                       GLOBAL VARIABLES
 *================================================================================================*/

/*==================================================================================================
 *                                       GLOBAL CONSTANTS
 *================================================================================================*/
#define GPT_START_SEC_CONFIG_DATA_UNSPECIFIED
#include "Gpt_MemMap.h"
#define GPT_STOP_SEC_CONFIG_DATA_UNSPECIFIED
#include "Gpt_MemMap.h"
/*==================================================================================================
 *                                       GLOBAL FUNCTIONS
 *================================================================================================*/

/*==================================================================================================
 *                                       LOCAL VARIABLES
 *================================================================================================*/

/*==================================================================================================
 *                          LOCAL TYPEDEFS (STRUCTURES, UNIONS, ENUMS)
 *================================================================================================*/

/*==================================================================================================
 *                                       LOCAL MACROS
 *================================================================================================*/

/*==================================================================================================
 *                                      LOCAL CONSTANTS
 *================================================================================================*/

/*==================================================================================================
 *                                       LOCAL FUNCTIONS
 *================================================================================================*/

/*==================================================================================================
 *                                   LOCAL FUNCTION PROTOTYPES
 *================================================================================================*/

#ifdef __cplusplus
}
#endif

/** @} */
